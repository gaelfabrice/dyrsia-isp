{include file="sections/header.tpl"}
<!-- user-edit -->

<form class="form-horizontal" method="post" role="form" action="{Text::url('settings/users-post')}">
    <input type="hidden" name="csrf_token" value="{$csrf_token}">
    <div class="row">
        <div class="col-sm-6 col-md-6">
            <div class="panel panel-primary panel-hovered panel-stacked mb30">
                <div class="panel-heading">{Lang::T('Profile')}</div>
                <div class="panel-body">
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('Full Name')}</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" id="fullname" name="fullname">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('Phone')}</label>
                        <div class="col-md-9">
                            <input type="number" class="form-control" id="phone" name="phone">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('Email')}</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" id="email" name="email">
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="city" name="city" placeholder="{Lang::T('City')}">
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="subdistrict" name="subdistrict" placeholder="{Lang::T('Sub District')}">
                        </div>
                        <div class="col-md-4">
                            <input type="text" class="form-control" id="ward" name="ward" placeholder="{Lang::T('Ward')}">
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="col-sm-6 col-md-6">
            <div class="panel panel-primary panel-hovered panel-stacked mb30">
                <div class="panel-heading">{Lang::T('Credentials')}</div>
                <div class="panel-body">
                    <div class="form-group" id="ispTenantGroup">
                        <label class="col-md-3 control-label">{Lang::T('ISP / Business Name')} <span class="text-danger">*</span></label>
                        <div class="col-md-9">
                            {if $requires_isp_choices}
                                <input type="text" class="form-control" name="isp_business_name" id="isp_business_name" list="isp-name-list" required
                                    placeholder="{Lang::T('Exact name of an existing ISP')}">
                                <datalist id="isp-name-list">
                                    {foreach $isp_tenants as $isp}
                                        <option value="{$isp['business_name']|escape}">
                                    {/foreach}
                                </datalist>
                                <p class="help-block" style="margin:6px 0 0;font-size:12px;">{Lang::T('Must match an existing provisioned ISP. One ISP per administrator.')}</p>
                            {elseif $creator_isp}
                                <input type="hidden" name="isp_business_name" value="{$creator_isp['business_name']|escape}">
                                <input type="text" class="form-control" value="{$creator_isp['business_name']|escape}" readonly>
                            {else}
                                <p class="text-danger" style="margin:0;">{Lang::T('No ISP linked to your account. Contact Super Admin.')}</p>
                            {/if}
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('User Type')}</label>
                        <div class="col-md-9">
                            <select name="user_type" id="user_type" class="form-control" onchange="checkUserType(this)">
                                {if $_admin['user_type'] eq 'Agent'}
                                    <option value="Sales">{Lang::T('Sales')}</option>
                                {/if}
                                {if $_admin['user_type'] eq 'Admin' || $_admin['user_type'] eq 'SuperAdmin'}
                                    <option value="Report">{Lang::T('Report Viewer')}</option>
                                    <option value="Agent">{Lang::T('Agent')}</option>
                                    <option value="Sales">{Lang::T('Sales')}</option>
                                {/if}
                                {if $_admin['user_type'] eq 'SuperAdmin'}
                                    <option value="Admin">{Lang::T('Administrator')}</option>
                                    <option value="SuperAdmin">{Lang::T('Super Administrator')}</option>
                                {/if}
                            </select>
                        </div>
                    </div>
                    <div class="form-group hidden" id="agentChooser">
                        <label class="col-md-3 control-label">{Lang::T('Agent')}</label>
                        <div class="col-md-9">
                            <select name="root" id="root" class="form-control">
                                {foreach $agents as $agent}
                                    <option value="{$agent['id']}">{$agent['username']} | {$agent['fullname']} | {$agent['phone']}</option>
                                {/foreach}
                            </select>
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('Username')}</label>
                        <div class="col-md-9">
                            <input type="text" class="form-control" id="username" name="username">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-3 control-label">{Lang::T('Password')}</label>
                        <div class="col-md-9">
                            <input type="password" class="form-control" id="password" value="{rand(000000,999999)}" name="password"
                            onmouseleave="this.type = 'password'" onmouseenter="this.type = 'text'">
                        </div>
                    </div>
                    <div class="form-group">
                        <label class="col-md-5 control-label">{Lang::T('Send Notification')}</label>
                        <div class="col-md-7">
                            <select name="send_notif" id="send_notif" class="form-control">
                                <option value="-">{Lang::T("Don't Send")}</option>
                                <option value="sms">{Lang::T('By SMS')}</option>
                                <option value="wa">{Lang::T('By WhatsApp')}</option>
                            </select>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="form-group text-center">
        <button class="btn btn-primary" onclick="return ask(this, 'Continue the process of adding Admin?')" type="submit">{Lang::T('Save Changes')}</button>
        Or <a href="{Text::url('settings/users')}">{Lang::T('Cancel')}</a>
    </div>
</form>
{literal}
    <script>
        function checkUserType($field){
            if($field.value=='Sales'){
                $('#agentChooser').removeClass('hidden');
            }else{
                $('#agentChooser').addClass('hidden');
            }
            var ispGroup = document.getElementById('ispTenantGroup');
            var ispInput = document.getElementById('isp_business_name');
            if (ispGroup && ispInput) {
                if ($field.value === 'SuperAdmin') {
                    ispGroup.classList.add('hidden');
                    ispInput.removeAttribute('required');
                } else {
                    ispGroup.classList.remove('hidden');
                    ispInput.setAttribute('required', 'required');
                }
            }
        }
        document.addEventListener('DOMContentLoaded', function () {
            var ut = document.getElementById('user_type');
            if (ut) checkUserType(ut);
        });
</script>
{/literal}

{include file="sections/footer.tpl"}
